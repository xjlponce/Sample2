# Face Detection Web Apps Using Flask , Opencv And  Python 

See the full video you will get somewhere the password of this code zip file

Requirement:
pip install opencv-python
pip install flask


🔥 Part 01: Real Time FACE Detection Web Apps l Flask Opencv & Python |  👉🏻https://youtu.be/C_JKIlc_wlU

🔥 Python Project: Automate Hill Climb 
Racing Game Using Python 👉🏻 https://youtu.be/ZBtk3GmJMTE


🔥 Hand Pose Estimation in 
Real Time Using Python & Mediapipe 👉🏻https://youtu.be/FN1wbvHjJdk


Like My Facebook Page: 

https://www.facebook.com/Knowledge-Doctor-Programming-114082097010409/
